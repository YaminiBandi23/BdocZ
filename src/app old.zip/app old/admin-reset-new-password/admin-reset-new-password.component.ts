import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-reset-new-password',
  templateUrl: './admin-reset-new-password.component.html',
  styleUrls: ['./admin-reset-new-password.component.css']
})
export class AdminResetNewPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
