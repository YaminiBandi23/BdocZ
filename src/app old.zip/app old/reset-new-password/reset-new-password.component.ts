import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-new-password',
  templateUrl: './reset-new-password.component.html',
  styleUrls: ['./reset-new-password.component.css']
})
export class ResetNewPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
