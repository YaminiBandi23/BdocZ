import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-password-mail',
  templateUrl: './reset-password-mail.component.html',
  styleUrls: ['./reset-password-mail.component.css']
})
export class ResetPasswordMailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
