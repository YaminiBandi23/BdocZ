import { Component, OnInit } from '@angular/core';
import { UserService } from '../user-service.service';
import {  Users} from "../users";

@Component({
  selector: 'app-my-transactions-latest',
  templateUrl: './my-transactions-latest.component.html',
  styleUrls: ['./my-transactions-latest.component.css']
})
export class MyTransactionsLatestComponent implements OnInit {

 transactionsData : any;
    cols: any[];


    constructor(private userService : UserService) { }

    ngOnInit() {

      this.userService.getMyTransactionsList().subscribe(response => {
        console.log(response);
         this.transactionsData = response;
       })

            this.cols = [
                { field: 'sentOn', header: 'Sent On' },
                { field: 'sentFrom', header: 'Sent From' },
                { field: 'sentTo', header: 'Sent To' },
                { field: 'documentName', header: 'Document Name' },
                { field: 'ethersBalance', header: 'Ethers Balance' },
                { field: 'status', header: 'Status' }

            ];
        }

      
        }

