import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-reset-password-mail',
  templateUrl: './admin-reset-password-mail.component.html',
  styleUrls: ['./admin-reset-password-mail.component.css']
})
export class AdminResetPasswordMailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
