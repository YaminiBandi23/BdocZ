import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-transaction-list',
  templateUrl: './admin-transaction-list.component.html',
  styleUrls: ['./admin-transaction-list.component.css']
})
export class AdminTransactionListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
