import { UserService } from './../user-service.service';
import { ChangePasswordComponent } from './../change-password/change-password.component';
import { Component, OnInit } from '@angular/core';
import {ProgressBarModule} from 'primeng/progressbar';
import { MessageService, ConfirmationService, Message} from 'primeng/api';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


interface States {
  name: string;
}

@Component({
  selector: 'app-transfer-new-docs',
  templateUrl: './transfer-new-docs.component.html',
  styleUrls: ['./transfer-new-docs.component.css'],
  providers: [ConfirmationService]
})
export class TransferNewDocsComponent implements OnInit {

  userName:String = "";
  sendersForm: FormGroup;
  date3: Date;
  val5 : 100;
  uploadedFiles: any[] = [];
   msgs: Message[] = [];
   cities2 : any;
   public senders: any[] = [{
    id: 1,
    firstName: '',
    lastName : '',
    dob: '',
    email : '',
    phoneNumber : '',
    streetAddress : '',
    city : '',
    zip : '',
    cities : '',
    fileUpload :''
  }];
  
  public receivers: any[] = [{
    id: 1,
    firstName: '',
    lastName : '',
    dob: '',
    email : '',
    phoneNumber : '',
    streetAddress : '',
    city : '',
    zip : '',
    state : '',
    fileUpload :''
  }];
  submitted: boolean;
  email: string;


  
  
  constructor(private messageService: MessageService, private router?:Router,  private formBuilder ? : FormBuilder,
    private confirmationService?: ConfirmationService) {
    this.cities2 = [
      {name: 'New York'},
      {name: 'Rome'},
      {name: 'London'},
      {name: 'Istanbul'},
      {name: 'Paris'}
    ];
   }
   
   onUpload(event) {
    for(let file of event.files) {
      console.log(this.uploadedFiles.push(file));
        this.uploadedFiles.push(file);
    }

    this.messageService.add({severity: 'info', summary: 'File Uploaded', detail: ''});
}


  ngOnInit() {
    this.sendersForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      lastName : new FormControl('', Validators.required),
      dob : new FormControl('', Validators.required),
       phoneNumber : new FormControl('', Validators.required),
       streetAddress : new FormControl('', Validators.required),
        city : new FormControl('', Validators.required),
        zip : new FormControl('', Validators.required),
       cities2 :new FormControl('', Validators.required),
            
  }); 
   
}

onSubmit() {
  this.submitted = true;
  console.log(this.sendersForm);
  if (this.sendersForm.invalid) {
      return;
  }
}
addSender() {
  this.senders.push({
    id: this.senders.length + 1,
    firstName: '',
    lastName : '',
    dob: '',
    email : '',
    phoneNumber : '',
    streetAddress : '',
    city : '',
    zip : '',
    state : '',
    fileUpload :''
   
  });
}

addReceiver() {
  this.receivers.push({
    id: this.receivers.length + 1,
    firstName: '',
    lastName : '',
    dob: '',
    email : '',
    phoneNumber : '',
    streetAddress : '',
    city : '',
    zip : '',
    state : '',
    fileUpload :''
   
  });
}

removeSender(i: number) {
    this.senders.splice(i, 1);
}

removeReceiver(i: number) {
  this.receivers.splice(i, 1);
}
logSender() {
  console.log(this.senders);
}

logReceiver() {
  console.log(this.receivers);
}



confirm() {
  this.confirmationService.confirm({
      message: 'Do you want to delete this record?',
      header: 'Delete Confirmation',
      icon: 'pi pi-info-circle',
      accept: () => {
        console.log(this.msgs = [{severity:'info', summary:'Confirmed', detail:'Record deleted'}]);
          this.msgs = [{severity:'info', summary:'Confirmed', detail:'Record deleted'}];
      },
      reject: () => {
        console.log( this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}]);
          this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
      }
  });
}           

confirmAndSend(){
  //this.router.navigateByUrl("/transationReceipt");
  }
}
 
  
  
