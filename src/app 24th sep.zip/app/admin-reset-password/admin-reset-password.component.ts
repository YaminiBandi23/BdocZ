import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-reset-password',
  templateUrl: './admin-reset-password.component.html',
  styleUrls: ['./admin-reset-password.component.css']
})
export class AdminResetPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
