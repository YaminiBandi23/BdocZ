class MyTransactions {
    sentOn: string;
    sentFrom: string;
    sentTo: string;
    documentName: string;
    ethersBalance: string;
    status: string;
    hashValue: string;


}
