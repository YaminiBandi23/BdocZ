export class Signin{
    email:string;
    password:string;
}