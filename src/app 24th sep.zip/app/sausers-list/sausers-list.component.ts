import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sausers-list',
  templateUrl: './sausers-list.component.html',
  styleUrls: ['./sausers-list.component.css']
})
export class SAUsersListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
