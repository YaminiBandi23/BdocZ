export class Signup{
  static module(arg0: string, arg1: undefined[]) {
    throw new Error("Method not implemented.");
  }
    firstName:string;
    lastName:string;
    dateOfBirth:number;
    email:string;
    password:string;
    confirmPassword:string;
    phoneNumber:number;
    ssnNumber:number;
    streetAddress:string;
    city:string;
    zip:number;
    state:string;
}