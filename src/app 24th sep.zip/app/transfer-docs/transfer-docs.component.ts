import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-docs',
  templateUrl: './transfer-docs.component.html',
  styleUrls: ['./transfer-docs.component.css']
})
export class TransferDocsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
