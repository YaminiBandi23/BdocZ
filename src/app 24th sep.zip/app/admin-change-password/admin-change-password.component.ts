import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-change-password',
  templateUrl: './admin-change-password.component.html',
  styleUrls: ['./admin-change-password.component.css']
})
export class AdminChangePasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
