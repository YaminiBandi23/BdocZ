import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-admin',
  templateUrl: './delete-admin.component.html',
  styleUrls: ['./delete-admin.component.css']
})
export class DeleteAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
