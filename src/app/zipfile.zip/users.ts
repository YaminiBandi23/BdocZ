export class Users {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    confirmPassword: string;
    phoneNumber: Number;
    socialSecurityNumber: string;
    streetAddress: string;
    city: string;
    stateName: string;
    zipCode :string;
    dateOfBirth :string;


 }