import { Users } from './users';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseurl = 'http://localhost:3000/users';
  newUsersurl = 'http://localhost:3000/newUsersData';

  

  constructor(private http: HttpClient) { }

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  // Post Users data
   addUsers(data): Observable<Users> {
     return this.http.post<Users>(this.newUsersurl, JSON.stringify(data), this.httpOptions)
     .pipe(
       retry(1),
       catchError(this.errorHandl)
     )
   } 
  

 // Get Users data
 getUsersList(): Observable<Users> {
  return this.http.get<Users>(this.baseurl)
    .pipe(
      retry(2),
      catchError(this.errorHandl)
    )
}

  
   // Error handling
   errorHandl(error) {
     let errorMessage = '';
     if(error.error instanceof ErrorEvent) {
       // Get client-side error
       errorMessage = error.error.message;
     } else {
       // Get server-side error
       errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
     }
     console.log(errorMessage);
     return throwError(errorMessage);
  }




}
