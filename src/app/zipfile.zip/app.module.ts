import { BrowserModule } from '@angular/platform-browser';
import { RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { ConfirmEqualValidatorDirective } from './signup/confirm-equal-validator.directive';
import { TransferNewDocsComponent } from './transfer-new-docs/transfer-new-docs.component';
import { TransactionReceiptComponent } from './transaction-receipt/transaction-receipt.component';
import { TransactionListComponent } from './transaction-list/transaction-list.component';
import { SadminUserslistComponent } from './sadmin-userslist/sadmin-userslist.component';
import { ResetPasswordMailComponent } from './reset-password-mail/reset-password-mail.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ResetNewPasswordComponent } from './reset-new-password/reset-new-password.component';
import { MyTransactionsLatestComponent } from './my-transactions-latest/my-transactions-latest.component';
import { LoginComponent } from './login/login.component';
import { DeleteAdminComponent } from './delete-admin/delete-admin.component';
import { ChangeProfileComponent } from './change-profile/change-profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AdminUserslistComponent } from './admin-userslist/admin-userslist.component';
import { AdminTransactionListComponent } from './admin-transaction-list/admin-transaction-list.component';
import { AdminResetPasswordMailComponent } from './admin-reset-password-mail/admin-reset-password-mail.component';
import { AdminResetPasswordComponent } from './admin-reset-password/admin-reset-password.component';
import { AdminResetNewPasswordComponent } from './admin-reset-new-password/admin-reset-new-password.component';
import { AdminListComponent } from './admin-list/admin-list.component';
import { AdminChangePasswordComponent } from './admin-change-password/admin-change-password.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
 import { NgModule } from '@angular/core';
 import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule  } from '@angular/common/http';
import { UserService } from './user-service.service';
import { NotificationModule } from './toastr-notification/toastr.notification.module';

var appRules = [
  {path:"signin",component:SigninComponent},
  {path:"signup",component:SignupComponent},
  {path:"",component:SigninComponent},
  {path:"reset-password",component:ResetPasswordComponent},
  {path:"transfer-new-docs",component:TransferNewDocsComponent}
  
]



@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    SignupComponent,
    ConfirmEqualValidatorDirective,
    TransferNewDocsComponent,
    TransactionReceiptComponent,
    TransactionListComponent,
    SadminUserslistComponent,
    ResetPasswordMailComponent,
    ResetPasswordComponent,
    ResetNewPasswordComponent,
    MyTransactionsLatestComponent,
    LoginComponent,
    DeleteAdminComponent,
    ChangeProfileComponent,
    ChangePasswordComponent,
    AdminUserslistComponent,
    AdminTransactionListComponent,
    AdminResetPasswordMailComponent,
    AdminResetPasswordComponent,
    AdminResetNewPasswordComponent,
    AdminListComponent,
    AdminChangePasswordComponent,
    AddAdminComponent,     
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRules),RouterModule,
    FormsModule, BrowserAnimationsModule, ReactiveFormsModule, HttpClientModule ,
    NgbModule, NotificationModule    

    
  ],
 
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
