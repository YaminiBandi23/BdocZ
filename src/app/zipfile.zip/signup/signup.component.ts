import { Users } from './../users';
import { UserService } from './../user-service.service';
import { SigninComponent } from "./../signin/signin.component";
import { Component, OnInit } from "@angular/core";
import { Signup } from "./signup";
import { NgbDatepickerConfig } from "@ng-bootstrap/ng-bootstrap";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, Routes } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { MustMatch } from "../_helpers/must-watch.validator";
import { NotificationService } from '../toastr-notification/toastr-notification.service';

const routes: Routes = [
  {path:"signin", component:SigninComponent},,
];

@Component({
  selector: "app-signup",
  templateUrl: "./signup.component.html",
  styleUrls: ["./signup.component.css"]
})
export class SignupComponent {
  State: any = ["Alabama", "Arkansas", "Arizona", "California", "Colorado"];
  maxDate = undefined;
  signUPForm: FormGroup;
  submitted = false;
  usersData: any;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
  phoneNumber: Number;
  socialSecurityNumber: string;
  streetAddress: string;
  city: string;
  zipCode :string;
  dateOfBirth :string;
  data: any;
  singUpDetails = {};

  constructor(
    private config?: NgbDatepickerConfig,
    private router?: Router, private _notificationservice ?:NotificationService,
    private httpClient?: HttpClient,
    private formBuilder?: FormBuilder,
    private  userService?: UserService) {
    const current = new Date();
    this.maxDate = {
      year: current.getFullYear(),
      month: current.getMonth() + 1,
      day: current.getDate()
    };

    this.data = [];
  }

  ngOnInit() {
    this.signUPForm = this.formBuilder.group(
      {
        firstName: ["", Validators.required],
        lastName: ["", Validators.required],
        email: ["", [Validators.required, Validators.email]],
        password: ["", [Validators.required, Validators.minLength(6)]],
        confirmPassword: ["", Validators.required],
        phoneNumber: ["", [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
        socialSecurityNumber: ["", Validators.required],
        streetAddress: ["", Validators.required],
        city: ["", Validators.required],
        stateName: ["", [Validators.required]],
        zipCode: ["", Validators.required],
        dateOfBirth: ['', Validators.required]
      },

      {
        validator: MustMatch("password", "confirmPassword")
      }
    );
  }

  changeState(e) {
    console.log(e.value);
    this.stateName.setValue(e.target.value, {
      onlySelf: true
    });
  }

  get stateName() {
    return this.signUPForm.get("stateName");
  }

  onSubmit() {
    this.submitted = true;
    console.log(" email is -----" + this.email);
    // stop the process here if form is invalid
    if (this.signUPForm.invalid) {
      return;
    }
     else
     {
      this.newUsers();
      setTimeout( () => {this.router.navigateByUrl("/signin");}, 2000 );
      this.showSuccessNotification();
     }
  }
  public showSuccessNotification(){  
    this._notificationservice.success("New User Created successfully");  
  }  
  
 newUsers(){

  this.userService.addUsers(this.singUpDetails).subscribe(res => {
    console.log('Data added!');
    this.data = res;

  })

 }
}
